import numpy as np
# from sklearn.decomposition import PCA

def perceptron(X_train, Y_train, eta, epochs):

    # Split data
    index_class0 = np.where(Y_train == 0)
    Y_train[index_class0] = -1

    (m,n) = X_train.shape
    X = np.hstack((X_train, np.ones((m,1))))
    y = Y_train.reshape((m,1))

    # attempt 3
    k = 0; w_k = np.zeros((n+1,)); alph = [0]; t = 0; T = epochs
    w_k = w_k.reshape(-1,1)
    # w = [w_k]
    converged = False
    while not converged and t <= T:
        converged = True
        for i, x_i in enumerate(X):
            x_i = x_i.reshape(-1,1)
            # yhat = y[i,0]*np.sign(np.dot(x_i.T, w[k]))
            yhat = y[i,0]*np.sign(np.dot(x_i.T, w_k))
            if yhat <= 0:
                w_k = w_k + eta * (y[i,0] * x_i)
                # w.append(w[k] + eta * (y[i,0] * x_i))
                # alph.append(1)
                # k += 1
                converged = False
            else:
                pass
                # alph[k] += 1
        t += 1
    t = w_k[-1]
    w = w_k[:-1]
    return w, t
    
    # return w, np.array(alph)

if __name__ == "__main__":
    pass
