import numpy as np

# This will be the code you will start with, note that the formate of the function 
# run (train_dir,test_dir,pred_file) and saving method can not be changed
# Feel free to change anything in the code

def run (train_input_dir,train_label_dir,test_input_dir,pred_file):
    # Reading data
    test_data = np.loadtxt(test_input_dir,skiprows=0)

    [num, _] = test_data.shape

    prediction = np.zeros((num, 1), dtype=np.int16)


    # Saving you prediction to pred_file directory (Saving can't be changed)
    np.savetxt(pred_file, prediction, fmt='%1d', delimiter=",")

    
if __name__ == "__main__":
    train_input_dir = 'training1.txt'
    train_label_dir = 'training1_label.txt'
    test_input_dir = 'testing1_label.txt'
    pred_file = 'result'
    run(train_input_dir,train_label_dir,test_input_dir,pred_file)
